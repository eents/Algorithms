﻿using System;

namespace FisherYatesShuffleAssignment
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] letters = { "A", "B", "C", "D", "E" };
            //letters.DoShuffle();
            letters.DoAlternateShuffle();
            foreach (string letter in letters)
            {
                Console.Write(letter + " ");
            }
            Console.ReadKey(true);
        }
    }
}
