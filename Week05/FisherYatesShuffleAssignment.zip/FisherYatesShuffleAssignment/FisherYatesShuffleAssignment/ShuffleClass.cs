﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// NOTES

// After the first tutorial, I like how he refactored the C#. It worked perfectly
// fine without the refactoring- but after the refactoring there's a clear separation
// of concern. It's good to practice not throwing every algorithm into the same
// method. 2 changes I would make to improve the code would be better names for
// the variables, and adding comments saying what each method is doing for future
// readability.

// After the second tutorial, I don't like how he refactored the C#. This would be
// fine for a personal project, but even then, future readability is rough. If you
// couldn't remember why you added +1s and -1s where you did. If I were to keep
// building the program out, I would give better names to the classes and treat
// them like libraries that more methods would be added to in the future. I prefer
// the first shuffle method because it does the exact same thing and is much more
// readable than the second.


namespace FisherYatesShuffleAssignment
{
    public static class ShuffleClass
    {
        private static Random random = new Random();

        public static void DoShuffle(this object[] objects)
        {
            for (int i = objects.Length - 1; i > 0; i--)
            {
                int j = GetRandomNumberBetweenZeroAnd(i);
                objects.SwapValuesAtIndicies(i, j);
            }
        }

        public static void DoAlternateShuffle(this object[] objects)
        {
            for (int i = 0; i < objects.Length - 2; i++)
            {
                int j = GetRandomNumberBetweenZeroAnd((objects.Length - i) - 1);
                objects.SwapValuesAtIndicies(i, i + j);
            }
        }

        private static int GetRandomNumberBetweenZeroAnd(int i)
        {
            return random.Next(i + 1);
        }
    }
}
