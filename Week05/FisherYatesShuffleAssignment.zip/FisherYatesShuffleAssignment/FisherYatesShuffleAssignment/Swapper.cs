﻿using System;
namespace FisherYatesShuffleAssignment
{
    public static class Swapper
    {
        public static void SwapValuesAtIndicies(this Object[] objects, int i, int j)
        {
            object temp = objects[i];
            objects[i] = objects[j];
            objects[j] = temp;
        }
    }
}
