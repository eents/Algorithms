﻿using System;
using static System.Console;

// Program by Eric Entsminger for PROG-366-01
// 9-15-2021

namespace BigONotation
{
    class Program
    {
        static void Main(string[] args)
        {
            // This is all brand new to me- If I have the wrong idea about anything
            // please let me know!!


                // O(1) Method

            bool Example = false;

            bool Return()
            {
                return Example;
            }

            Return();

            // This is an O(1) algorithm because it will always take the same amount
            // of time to execute.


                // O(n) Method

            string[] animals = new string[4];
            animals[0] = "Gecko";
            animals[0] = "Ostrich";
            animals[0] = "Walrus";
            animals[0] = "Emu";

            string ContainsOstrich()
            {
                foreach (string i in animals)
                {
                    if (i == "Ostrich")
                        return $"{i}, Found one!";
                    else
                        return $"{i}";
                }

                return $"end";
            }

            ContainsOstrich();

            // This is an O(n) algorithm because the runtime will change based on
            // the size of n. In this case, the size of the array.


            // O(n^2) Method

            // An O(n^2) algorithm has to go through nested steps. I'm really
            // struggling with all of this. I will do my best to study up and
            // come back to this assignment, but now I have another class.
            // I could really use a demo of all of these in class.

        }
    }
}
